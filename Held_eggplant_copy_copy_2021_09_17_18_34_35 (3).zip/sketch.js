const operadores = ['+', '-', '*', '/']

function pegaOperador(operadores) {
  let escolha = Math.floor(Math.random()*operadores.length)
  return operadores[escolha]
}

function numeroAleatorio(){
  return Math.floor(Math.random()*100)
}

var pontos = 0

var x_menu = 80
var y_menu = 100
var x_jogo = 60
var y_jogo = 200
var opcao_menu = 1
var opcao_jogo = 1
var tela = 0
var n_questao = 1
let img;

function preload(){  
  img = loadImage('tela-inicial-jogo-thalys.jpg');
}

let num1;
let num2;
let operador;
let resultado;

let alternativas;
let x;
let op_a;
let op_b;
let op_c;
let op_d;

function setup() {
    createCanvas(400, 400)
}

function draw() {
  image(img, -110, 0)
  if (tela == 0) {
    menu()  
  }
  if (tela == 1) {
    Jogar()
  }
  if (tela == 2) {
    Instrucao()
  }
  if (tela == 3) {
    Credito()
  }
  if (tela == 4) {
    Perdeu()
  }
}

function menu() {
    textSize(32)
    fill(0)
    rect(x_menu, y_menu, 170, 45)
    fill(61,252,3)
    text('Jogar', 90, 130)
    text('Instruções', 90, 230)
    text('Créditos', 90, 330)
}

function keyPressed() {
  if (keyCode == ESCAPE) {
    tela = 0;
    pontos = 0;
    n_questao = 0;
  }
  
  if (tela == 1) {
    if (key == 'ArrowUp' && y_jogo != 200) {
      y_jogo -= 40
      opcao_jogo--
    }
    
    if (key == 'ArrowDown' && y_jogo != 320) {
      y_jogo += 40
      opcao_jogo++
      console.log(opcao_jogo + ' ' + x)
    }
    
    if (key == 'Enter') {
      if (opcao_jogo - 1 == x) {
        pontos += 10
        n_questao++
        sorteioQuestao()
      } else {
        tela = 4
      }
    }
  } else {
    if (key == 'ArrowUp' && y_menu != 100) {
      y_menu-=100
      opcao_menu--
    }
    if (key == 'ArrowDown' && y_menu != 300) {
      y_menu+=100
      opcao_menu++
    }
    if (key == 'Enter') {
      tela = opcao_menu
      
      if (opcao_menu === 1) {
        sorteioQuestao()
      }
    }
  }
}

function sorteioQuestao () {
  num1 = numeroAleatorio()
  num2 = numeroAleatorio()
  operador = pegaOperador(operadores)
  resultado = eval(`${num1} ${operador} ${num2}`)
  
  alternativas = [numeroAleatorio(), numeroAleatorio(), numeroAleatorio(), numeroAleatorio()]
  x = Math.floor(Math.random()*3)
  
  alternativas[x] = resultado;
  
  op_a = alternativas[0]
  op_b = alternativas[1]
  op_c = alternativas[2]
  op_d = alternativas[3]
}

function Jogar() {
  textSize(32)
  fill(61,252,3)
  text(`Questão: ${n_questao}`, 10, 130)
  
  textSize(20)
  text(`${num1} ${operador} ${num2} = ?`, 10, 160)
  
  fill(0)
  rect(x_jogo, y_jogo, 180, 30)
  
  fill(61,252,3)
  text(`a) ${op_a}`, 70, 220)
  text(`b) ${op_b}`, 70, 260)
  text(`c) ${op_c}`, 70, 300)
  text(`d) ${op_d}`, 70, 340)
  
  text(`Pontos: ${pontos}`, 10, 380)
}

function Instrucao() {
  textSize(32)
  fill(255)
  text('Instruções', 10, 130)
  textSize(12)
  fill(255)
  rect(5, 135, 250, 80)
  fill(0)
  text('Resolva as expressões númericas,\ncaso você erre uma questão o jogo\n reiniciará. Tente fazer o máximo\n de questões que você puder tá okey?', 10, 150)
  
}

function Credito() {
  textSize(32)
  fill(255)
  text('Créditos', 10, 130)
  textSize(12)
  fill(255)
  rect(5, 135, 250, 80)
  fill(0)
  text('Thalys Ribeiro de Albuquerque Silva\nEstudante do curso Bacharelado em Ciência\ne Tecnologia', 10, 150)
}

function Perdeu() {
  textSize(32)
  fill(0)
  rect(0, 135, 400, 150)
  fill(61,252,3)
  text(`Você perdeu\nPontos feitos: ${pontos}`, 100, 200)
}